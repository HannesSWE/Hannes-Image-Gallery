Exctract the folder.
To use the image gallery, please open hannes_image_gallery.html.